export declare const crypto: any;
//# sourceMappingURL=cryptoNode.d.ts.map