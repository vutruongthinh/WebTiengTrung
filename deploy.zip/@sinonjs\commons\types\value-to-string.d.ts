export = valueToString;
/**
 * Returns a string representation of the value
 * @param  {*} value
 * @returns {string}
 */
declare function valueToString(value: any): string;
